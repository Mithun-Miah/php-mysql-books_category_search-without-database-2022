<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Engine</title>

    <style>
        body{
            background-color: slategray;
            margin: 0px;
            padding: 0px;
            width: 100vw;
            height: 100vh;
            box-sizing: border-box;
        }
        .container{
            width: 80vw;
            height: auto;
            margin: auto;
            text-align: center;
            border: 2px solid red;
            padding-bottom: 5px;
        }
        .heading1{
            color: white;
            font-weight: 800;
            text-shadow: 5px 5px 5px rgb(5, 5, 5);
        }
        .heading2{
            color: yellow;
            font-weight: 800;
            text-shadow: 5px 5px 5px rgb(5, 5, 5);
        }
        .searchInput{
            width: 40%;
            height: 40px;
            padding: 5px;
            border-radius: 7px;
            font-size: 16px;
        }
        .searchBtn{
            width: 15%;
            height: 40px;
            padding: 5px;
            border-radius: 7px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.1s ease-in;
        }
        .searchBtn:hover{
            border: none;
            background-color: teal;
            color: white;
        }
        .catAdd{
            width: 30%;
            height: 25px;
            padding: 5px;
            border-radius: 7px;
            font-size: 16px;
        }
        .subCatAdd{
            width: 30%;
            height: 25px;
            padding: 5px;
            border-radius: 7px;
            font-size: 16px;
        }
        .addBtn,.updateBtn,.delBtn,.clearBtn{
            width: 8%;
            height: 40px;
            padding: 5px;
            border-radius: 7px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.1s ease-in;
        }
        .addBtn:hover{
            border: none;
            background-color: teal;
            color: white;
        }
        .updateBtn:hover{
            border: none;
            background-color: darkgreen;
            color: white;
        }
        .delBtn:hover{
            border: none;
            background-color: red;
            color: white;
        }
        .clearBtn:hover{
            border: none;
            background-color: steelblue;
            color: white;
        }
        .display_data h3{
            color: #000;
            background-color: steelblue;
            padding: 10px;
            text-transform: uppercase;
            text-decoration: underline;
        }
        table{
            border: 1px solid black;
            border-collapse: collapse;
            text-align: center;
            margin: auto;
            width: 100vh;
        }
        th{
            color: yellow;
            font-size: 1.2rem;
            letter-spacing: 1.5px;
        }
        td{
            color: #fff;
            font-size: 1rem;
            letter-spacing: 1.1px;
        }
        tr,th,td{
            border: 1px solid black;
            padding: 5px;
        }

    </style>
</head>
<body>

    <div class="container">
        <form action="" method="post">
            <h1 class="heading1">Add Books Category And Sub-Category</h1>
            <input type="text" name="category" placeholder="type books category" class="catAdd">
            <input type="text" name="subCategory" placeholder="type books sub-category" class="subCatAdd">
            <br><br>
            <input type="submit" name="add" value="Add" class="addBtn">
            <input type="submit" name="update" value="Update" class="updateBtn">
            <input type="submit" name="delete" value="Delete" class="delBtn">
            <input type="submit" name="clear" value="Clear" class="clearBtn">
        </form>

        <form action="" method="post">
            <h1 class="heading2">Search Engine For Books Category</h1>
            <input type="search" name="search" placeholder="search by category" class="searchInput">
            <input type="submit" name="submit" value="Search" class="searchBtn">
        </form>

        <div class="display_data">
            <h3>Show Category and Sub-Category</h3>
            <table>
                <thead>
                    <tr>
                        <th>Category</th>
                        <th>Sub-Category</th>
                    </tr>
                    
                </thead>
                <tbody>
                    <tr>
                        <td>Engineering</td>
                        <td>Architechture</td>
                    </tr>
                </tbody>
                
            </table>
        </div>
    </div>
    
</body>
</html>